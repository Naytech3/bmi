# bmi

A Pen created on CodePen.io. Original URL: [https://codepen.io/NAYFATH/pen/MYgdvwz](https://codepen.io/NAYFATH/pen/MYgdvwz).

